import requests
from api.core.config import settings

class JiraAPIWrapper:
    def __init__(self):
        self.base_url = "https://jira.example.com/api"
        self.api_key = settings.API_KEY

    async def get_data(self, query: str):
        url = f"{self.base_url}/search?jql={query}"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        response = requests.get(url, headers=headers)
        return response.json()
