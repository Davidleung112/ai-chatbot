class GitHubAPIWrapper:
    def __init__(self):
        self.api_url = "https://api.github.com"

    async def get_data(self, repo_name: str):
        return f"Fetched data for {repo_name}"
