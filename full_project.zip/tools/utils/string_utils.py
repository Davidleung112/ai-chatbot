def to_upper_case(string):
    return string.upper()
