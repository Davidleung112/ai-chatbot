from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

class DataProcessingTool:
    def __init__(self):
        self.llm = OpenAI(temperature=0.7)
        self.prompt_template = PromptTemplate(input_variables=["data_query"], template="Process the following data query: {data_query}")
        self.chain = LLMChain(prompt=self.prompt_template, llm=self.llm)

    async def run(self, data_query):
        return await self.chain.run(data_query)
