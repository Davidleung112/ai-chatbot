from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

class QuestionAnsweringTool:
    def __init__(self):
        self.llm = OpenAI(temperature=0.7)
        self.prompt_template = PromptTemplate(input_variables=["question"], template="Answer the following question: {question}")
        self.chain = LLMChain(prompt=self.prompt_template, llm=self.llm)

    async def run(self, question: str):
        return await self.chain.run(question)
