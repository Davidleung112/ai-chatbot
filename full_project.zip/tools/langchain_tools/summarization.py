from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

class SummarizationTool:
    def __init__(self):
        self.llm = OpenAI(temperature=0.7)
        self.prompt_template = PromptTemplate(input_variables=["text"], template="Summarize the following text: {text}")
        self.chain = LLMChain(prompt=self.prompt_template, llm=self.llm)

    async def run(self, text: str):
        return await self.chain.run(text)
