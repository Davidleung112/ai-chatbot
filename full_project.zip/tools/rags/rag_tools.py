class RagTool:
    def __init__(self):
        pass

    async def run(self, query: str):
        return f"RAG result for {query}"
