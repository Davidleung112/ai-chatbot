from fastapi import FastAPI
from api.endpoints import data_related, jira_related, github, jenkins
from api.security.auth import AuthService
from api.core.config import settings

app = FastAPI(title="Professional API", version="1.0")

app.include_router(data_related.router, prefix="/data", tags=["Data"])
app.include_router(jira_related.router, prefix="/jira", tags=["Jira"])
app.include_router(github.router, prefix="/github", tags=["GitHub"])
app.include_router(jenkins.router, prefix="/jenkins", tags=["Jenkins"])
