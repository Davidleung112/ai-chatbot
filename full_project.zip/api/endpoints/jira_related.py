from fastapi import APIRouter, Depends
from api.services.api_service import ApiService
from api.security.auth import AuthService

router = APIRouter()

@router.post("/jira-query/")
async def jira_query(query: str, current_user: dict = Depends(AuthService().get_current_user)):
    api_service = ApiService()
    result = await api_service.process_jira_query(query)
    return result
