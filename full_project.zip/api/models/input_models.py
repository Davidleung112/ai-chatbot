from pydantic import BaseModel

class JiraQueryRequest(BaseModel):
    query: str
