from pydantic import BaseModel

class JiraQueryResponse(BaseModel):
    result: str
