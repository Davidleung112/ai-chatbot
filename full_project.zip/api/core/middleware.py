from fastapi.middleware.cors import CORSMiddleware
from fastapi import Request
import logging

logger = logging.getLogger("project_logger")

class Middleware:
    def __init__(self, app):
        self.app = app

    def __call__(self, request: Request, *args, **kwargs):
        logger.info(f"Request: {request.method} {request.url}")
        response = self.app(request, *args, **kwargs)
        logger.info(f"Response: {response.status_code}")
        return response

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
