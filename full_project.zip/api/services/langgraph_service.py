from tools.langgraph_tools.api_wrappers import GitHubAPIWrapper

class LangGraphService:
    def __init__(self):
        self.github_wrapper = GitHubAPIWrapper()

    async def fetch_github_data(self, repo_name: str):
        return await self.github_wrapper.get_data(repo_name)
