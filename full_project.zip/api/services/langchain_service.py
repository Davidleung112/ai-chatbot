from tools.langchain_tools.question_answering import QuestionAnsweringTool
from tools.langchain_tools.summarization import SummarizationTool

class LangChainService:
    def __init__(self):
        self.qa_tool = QuestionAnsweringTool()
        self.summarization_tool = SummarizationTool()

    async def process_qa(self, query: str):
        response = await self.qa_tool.run(query)
        return response

    async def summarize_text(self, text: str):
        summary = await self.summarization_tool.run(text)
        return summary
