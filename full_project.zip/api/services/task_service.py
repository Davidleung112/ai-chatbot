class TaskService:
    def __init__(self):
        pass

    async def handle_long_running_task(self):
        # handle long-running task, for example using asyncio.sleep
        pass
