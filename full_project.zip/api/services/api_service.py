from tools.api_wrappers.jira import JiraAPIWrapper
from tools.langchain_tools.question_answering import QuestionAnsweringTool

class ApiService:
    def __init__(self):
        self.jira_wrapper = JiraAPIWrapper()
        self.qa_tool = QuestionAnsweringTool()

    async def process_jira_query(self, query: str):
        jira_data = await self.jira_wrapper.get_data(query)
        response = await self.qa_tool.run(f"Answer the question based on the Jira data: {jira_data}")
        return response
