from tools.langgraph_tools.data_integration import DataIntegrationTool
from api.services.langchain_service import LangChainService

class WorkflowService:
    def __init__(self):
        self.data_integration_tool = DataIntegrationTool()
        self.langchain_service = LangChainService()

    async def run_full_workflow(self, query: str):
        data = await self.data_integration_tool.run(query)
        return await self.langchain_service.process_qa(data)
