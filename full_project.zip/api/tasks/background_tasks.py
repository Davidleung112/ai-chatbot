from fastapi import BackgroundTasks
from tools.api_wrappers.jira import JiraAPIWrapper

def fetch_jira_data(query: str, background_tasks: BackgroundTasks):
    background_tasks.add_task(JiraAPIWrapper().get_data, query)
