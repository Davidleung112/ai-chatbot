from time import time
from collections import defaultdict
from typing import Dict

class RateLimiter:
    def __init__(self, rate_limit: int, time_window: int):
        self.rate_limit = rate_limit  # Maximum requests per time window
        self.time_window = time_window  # Time window in seconds
        self.requests: Dict[str, list] = defaultdict(list)

    def is_request_allowed(self, user_id: str) -> bool:
        current_time = time()
        self.requests[user_id] = [req for req in self.requests[user_id] if req > current_time - self.time_window]

        if len(self.requests[user_id]) < self.rate_limit:
            self.requests[user_id].append(current_time)
            return True
        return False
