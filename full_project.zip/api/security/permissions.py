from fastapi import HTTPException, status

class Permissions:
    @staticmethod
    def check_admin(user_role: str):
        if user_role != "admin":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You don't have enough permissions",
            )
