from fastapi.testclient import TestClient
from api.app import app

client = TestClient(app)

def test_jira_query():
    response = client.post("/jira/jira-query/", json={"query": "project = TEST"})
    assert response.status_code == 200
    assert "result" in response.json()
