from api.services.api_service import ApiService
from tools.api_wrappers.jira import JiraAPIWrapper

def test_process_jira_query():
    api_service = ApiService()
    result = api_service.process_jira_query("project = TEST")
    assert result is not None
